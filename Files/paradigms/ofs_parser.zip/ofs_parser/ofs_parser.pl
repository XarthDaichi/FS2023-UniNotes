/*
    CFG
    foo -> "hola" goo
    goo -> "!"
    foo -> "hola" goo -> "hola" "!" -> "hola!"
*/

/*

foo --> "hola", goo.
goo --> "!".

foo_1 --> [hola], goo_1.
goo_1 --> [!].
*/

/*
    CFG
    ofs_parser -> statement
    statement -> "const" ident ("=" expr)? (";")?
    ident -> [a-zA-Z_$][a-zA-Z_$0-9]*
    number -> [+-]?[0-9]+

    expr -> ident ; number
*/


ofs_parser --> statement, ofs_parser.
ofs_parser --> [].

statement --> const, ident, right_side.
statement --> semicolon.
statement --> comment.

comment --> comment_start, words, comment_end.

comment_start --> spaces, "//", spaces.
comment_end --> spaces, "\n".

words --> spaces, alpha_numeric_char, spaces, words.
words --> [].

right_side --> assignment, expr.
right_side --> [].

semicolon --> spaces, ";", spaces.

ident --> letter, letters, spaces.

number --> entero, spaces.

assignment --> "=", spaces.

const --> spaces, "const", space, spaces.

expr --> list ; ident ; number.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TOKENIZER = LEXER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% whitespaces
space --> " " ; "\t" ; "\n" ; "\r".

spaces --> space, spaces.
spaces --> [].

% numbers
decimal --> "0" ; "1" ; "2" ; "3" ; "4" ; "5" ; "6" ; "7" ; "8" ; "9".
sign --> "-" ; "+".

entero --> sign, entero.
entero --> decimal, entero.
entero --> [].

% letters
accepted_char --> "_" ; "$".
lower_letter --> "a" ; "b" ; "c" ; "d" ; "e" ; "f" ; "g" ; "h" ; "i" ; "j" ; "k" ; "l" ; "m" ; "n" ; "o" ; "p" ; "k" ; "r" ; "s" ; "t" ; "u" ; "v" ; "w" ; "x" ; "y" ; "z".
upper_letter --> "A" ; "B" ; "C" ; "D" ; "E" ; "F" ; "G" ; "H" ; "I" ; "J" ; "K" ; "L" ; "M" ; "N" ; "O" ; "P" ; "K" ; "R" ; "S" ; "T" ; "U" ; "V" ; "W" ; "X" ; "Y" ; "Z".

letter --> accepted_char ; lower_letter ; upper_letter.
alpha_numeric_char --> letter ; decimal.

letters --> alpha_numeric_char, letters.
letters --> [].

% list
list -->  "[", list_content ,"]", spaces.

list_content --> list_element, comma, list_content.
list_content --> list_element.

list_element --> spaces, expr, spaces.

comma --> spaces, ",", spaces.