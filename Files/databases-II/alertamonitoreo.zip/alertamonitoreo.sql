CREATE OR REPLACE PROCEDURE AlertaMonitoreo(hwm IN NUMBER) AS
  file_handle UTL_FILE.FILE_TYPE;
  cursor c_data is
    SELECT b.id, b.name, b.block_size/1024/1024 AS size_mb,
       (b.block_size/1024/1024) - (b.free_buffer_inspected/1024/1024) AS used_mb,
       b.free_buffer_inspected/1024/1024 AS free_mb,
       s.username, s.sid, s.serial#, s.sql_id,
       t.sql_text
      FROM v$buffer_pool_statistics b
      JOIN v$session s ON b.con_id = s.sid
      LEFT JOIN v$sqltext t ON s.sql_id = t.sql_id
      WHERE s.status = 'ACTIVE' AND s.username IS NOT NULL;
BEGIN
  -- Open the file for writing
  file_handle := UTL_FILE.FOPEN('C:\Temp', 'output.txt', 'W');

  -- Loop through the table rows and write data to the file
  -- UTL_FILE.PUT_LINE(file_handle, 'HELLO WORLD!!!!');
  for rec in c_data loop
    IF hwm < rec.used_mb THEN
      DBMS_OUTPUT.PUT_LINE(rec.id || ',' || rec.name || ',' || rec.size_mb || ',' || rec.used_mb || ',' || rec.free_mb || ',' || rec.username || ',' || rec.sid || ',' || rec.serial# || ',' || rec.sql_id || ',' || rec.sql_text);
      UTL_FILE.PUT_LINE(file_handle, rec.id || ',' || rec.name || ',' || rec.size_mb || ',' || rec.used_mb || ',' || rec.free_mb || ',' || rec.username || ',' || rec.sid || ',' || rec.serial# || ',' || rec.sql_id || ',' || rec.sql_text); -- Adjust columns accordingly
    END IF;
  end loop;

  -- Close the file
  UTL_FILE.FCLOSE(file_handle);
EXCEPTION
  WHEN UTL_FILE.INVALID_OPERATION THEN
    DBMS_OUTPUT.PUT_LINE('Invalid operation on file.');
  WHEN UTL_FILE.INVALID_FILEHANDLE THEN
    DBMS_OUTPUT.PUT_LINE('Invalid file handle.');
  WHEN UTL_FILE.WRITE_ERROR THEN
    DBMS_OUTPUT.PUT_LINE('Write error.');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An error occurred.');
END;
/

SET SERVEROUTPUT ON
BEGIN
    AlertaMonitoreo(1000);
END;
/
